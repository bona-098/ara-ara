<?php
// $subject = "Daily KF Planting Report";
// $message = "<p>Dear Plantation Managers</p>
			// <p>Attached Planting Report as of : 10/10/2019, this report generated automatically from  PM Online, you can access directly from http://172.18.80.201/pm/reportplanting 
			// <br>Please don't hesitate to contact us if you don't have access, or you have difficulty on accessing PM Online
			// <br>Thank You</p>
			
			// <br><br>
			// Regards
			// <br>
			// <br>
			// KF Planning Intranet Services
			// <hr>
			// <small>Note: This email send automatically from PM Online ( http://172.18.80.201/pm )</small>";
// $FilePath="D:\\Planting_Report_10102019.xlsx";
// if (!defined("olMailItem")) {define("olMailItem",0);}
// $oApp  = new COM("Outlook.Application") or die('error');
// $oMsg = $oApp->CreateItem(olMailItem);
// $oMsg->Recipients->Add("purwanto_ihm@itci-hutani.com");
// $myRecipient = $oMsg->Recipients->Add("purwanto_ihm@itci-hutani.com");
// $myRecipient->Type = 3;
// $oMsg->Subject=$subject;
// $oMsg->HTMLBody=$message;
// $oMsg->Attachments->Add($FilePath);
// $oMsg->Save();
// $oMsg->Send();
// 


require '../pms/PHPMailer-master/PHPMailerAutoload.php';

//Create a new PHPMailer instance
$mail = new PHPMailer;

//Tell PHPMailer to use SMTP
$mail->isSMTP();

//Enable SMTP debugging
// 0 = off (for production use)
// 1 = client messages
// 2 = client and server messages
$mail->SMTPDebug = 2;

//Ask for HTML-friendly debug output
$mail->Debugoutput = 'html';

//Set the hostname of the mail server
$mail->Host = 'd1jkts03b.d1.lcl'; //'d1jkts03a.d1.lcl';
// use
// $mail->Host = gethostbyname('smtp.gmail.com');
// if your network does not support SMTP over IPv6

//Set the SMTP port number - 587 for authenticated TLS, a.k.a. RFC4409 SMTP submission
$mail->Port = 465;

//Set the encryption system to use - ssl (deprecated) or tls
$mail->SMTPSecure = 'tls';

//Whether to use SMTP authentication
$mail->SMTPAuth = true;

//Username to use for SMTP authentication - use full email address for gmail
$mail->Username = "online_system@d1.lcl";

//Password to use for SMTP authentication
$mail->Password = "Password1";

//Set who the message is to be sent from
$mail->setFrom('online_system@d1.lcl',"Online Approval System");

//Set an alternative reply-to address
$mail->addReplyTo('Purwanto_ihm@itci-hutani.com', 'Purwanto');

//Set who the message is to be sent to
$mail->addAddress('Purwanto_ihm@itci-hutani.com', 'Planning admin');

//$mail->addCC('Purwanto_ihm@itci-hutani.com');
//$mail->addBCC('Purwanto_ihm@itci-hutani.com');


//Set the subject line
$mail->Subject = "OAsys Test Mail";

//Read an HTML message body from an external file, convert referenced images to embedded,
//convert HTML into a basic plain-text alternative body
//$mail->msgHTML(file_get_contents('content.php'), dirname(__FILE__));
$mail->msgHTML("Test send Mail");
//Replace the plain text body with one created manually
$mail->AltBody = 'Terlampir';

//Attach an image file
//$mail->addAttachment('4.png');

//send the message, check for errors
if (!$mail->send()) {
    echo "Mailer Error: " . $mail->ErrorInfo;
} else {
    echo "Message sent!";
}

