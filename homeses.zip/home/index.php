
<?php
if (preg_match('/MSIE\s(?P<v>\d+)/i', @$_SERVER['HTTP_USER_AGENT'], $B) || preg_match('/Edge/i', @$_SERVER['HTTP_USER_AGENT'], $B)) {
	session_start();
	$_SESSION['previous_location'] = 'home';
    header("location:/outdatedbrowser");
}
?>
<!doctype html>
<html class="no-js" lang="en">

    <head>
        <!-- meta data -->
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
		<link href="https://fonts.googleapis.com/css?family=Poppins:100,100i,200,200i,300,300i,400,400i,500,500i,600,600i,700,700i,800,800i,900,900i" rel="stylesheet">
        <title>Welcome to KDU Planning Intranet</title>
		<link rel='shortcut icon' href='http://172.18.83.35/home/server.ico'>
		<meta charset="utf-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1" />
		<link rel="shortcut icon" type="image/icon" href="assets/logo/favicon.png"/>
        <!-- <link rel="stylesheet" href="assets/css/font-awesome.min.css">
        <link rel="stylesheet" href="assets/css/animate.css">
        <link rel="stylesheet" href="assets/css/flaticon.css">
        <link rel="stylesheet" href="assets/css/slick.css">
		<link rel="stylesheet" href="assets/css/slick-theme.css"> -->
        <link rel="stylesheet" href="assets/css/bootstrap.min.css">
		<link rel="stylesheet" href="assets/css/bootsnav.css" >	
        <link rel="stylesheet" href="assets/css/style.css">
        <link rel="stylesheet" href="assets/css/responsive.css">


    </head>
	
	<body>
		<!--[if lte IE 9]>
            <p class="browserupgrade">You are using an <strong>outdated</strong> browser. Please <a href="https://browsehappy.com/">upgrade your browser</a> to improve your experience and security.</p>
        <![endif]-->

		<!--welcome-hero start -->
		<section id="home" class="welcome-hero">
			<!-- <div class="container"> -->
				<div class="welcome-hero-txt">
					<div class="logo">
						<div class="logoIHM"></div>
						<div class="logoAHL"></div>
						<div class="logoNKL"></div>
						<h2>KF PLANNING Intranet Services</h2>
						<h5>
							Click icon below to open Application  
						</h5>
					</div>
					<div class="container">
					<div class="list-topics-content">
								<ul>
										<a href="/pms" class="card">										
											<div>
												<img src="images/1.png">
												<h6 class="card-title">Phantom Monitoring Services</h6>
																	
											</div>
										</a>
										<a href="/iop" class="card">
											<div>
												<img src="images/2.png">
												<h6>Integrated Operation Plan</h6>
											</div>
										</a>
									
										<a href="/pm" class="card">
											<div>
												<img src="images/3.png">
												<h6>Plantation Management</h6>
											</div>
										</a>
									
									
										<a href="/meeting" class="card">
											<div>
												<img src="images/4.png">
												<h6>KF Meeting Room Booking System</h6>
											</div>
										</a>
										<a href="/oasys" class="card">
											<div>
												<img src="images/8.png">
												<h6>OASys (Online Approval System)</h6>
											</div>
										</a>
										<a href="/pmrs" class="card">
											<div>
												<img src="images/7.png">
												<h6>PMRS (Planning Monitoring & Reporting System)</h6>
											</div>
										</a>
										<a href="/WEBMAP" class="card">
											<div>
												<img src="images/6.png">
												<h6>WEBMAP</h6>
											</div>
										</a>
										<a href="/devportal" class="card">
										<div>	
												<img src="images/5.png">
												<h6>DevPortal</h6>
											</div>
										</a>									
								</ul>	
							</div>
						</div>											
					</div>					
					<footer id="footer">
						<span class="copyright">&copy; 2018 KF Planning Intranet Services</span>
					</footer>													
					</div>		

				</section>
		<script src="assets/js/jquery.js"></script>
        <!-- <script src="https://cdnjs.cloudflare.com/ajax/libs/modernizr/2.8.3/modernizr.min.js"></script> -->
		
		<!--bootstrap.min.js-->
        <script src="assets/js/bootstrap.m	in.js"></script>
		
		<!-- bootsnav js -->
		<!-- <script src="assets/js/bootsnav.js"></script> -->

        <!--feather.min.js-->
        <!-- <script  src="assets/js/feather.min.js"></script> -->

        <!-- counter js -->
		<!-- <script src="assets/js/jquery.counterup.min.js"></script> -->
		<!-- <script src="assets/js/waypoints.min.js"></script> -->

        <!--slick.min.js-->
        <!-- <script src="assets/js/slick.min.js"></script> -->

		<!-- <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-easing/1.4.1/jquery.easing.min.js"></script> -->
		     
        <!--Custom JS-->
        <script src="assets/js/custom.js"></script>
        
    </body>
	
</html>